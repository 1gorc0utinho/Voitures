function buttonBlack(){
  document.body.style.backgroundColor = "black"
}
function buttonRed(){
  document.body.style.backgroundColor = "#8C0303"
}
function buttonYellow(){
  document.body.style.backgroundColor = "#D9851E"
}
function buttonBlue(){
  document.body.style.backgroundColor = "#1C588C"
}
function buttonWhite(){
  document.body.style.backgroundColor = "white"
}